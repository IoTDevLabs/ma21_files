# find_face_mediumone.py
#
# Sipeed Maixduino face detection and send events to Medium One

import sensor, image, lcd, time
import KPU as kpu
import gc, sys
import time, network
from Maix import GPIO
from fpioa_manager import fm
import usocket as socket
import ustruct as struct
from ubinascii import hexlify
import json

# Set to your own parameters

# Params

WIFI_SSID      = "YOUR_SSID"
WIFI_PASSWORD  = "YOUR_PASSWORD"

MQTT_BROKER    = "mqtt.mediumone.com"
MQTT_PORT      = 61617      # unencrypted port
MQTT_USERNAME  = "xxxxxxxxxxx/xxxxxxxxxxx"
MQTT_PASSWORD  = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/xxxxxxxxxxxxxxxxx"
MQTT_CLIENT_ID = "mydevice"
MQTT_PUB_TOPIC = "0/xxxxxxxxxxx/xxxxxxxxxxx/mydevice"

# Globals

mqtt_connected = False
client = None
face_count = 0
last_face_count = -1

# MQTT classes

class MQTTException(Exception):
    pass

class MQTTClient:

    connect_status_codes = ["Connection accepted", "Connection refused, unacceptable protocol version",
        "Connection refused, identifer rejected", "Connection refused, server unavailable",
        "Connection refused, bad user name or password", "Connection refused, not authorized"]

    def __init__(self, client_id, server, port=0, user=None, password=None, keepalive=0,
                 ssl=False, ssl_params={}):
        if port == 0:
            port = 8883 if ssl else 1883
        self.client_id = client_id
        self.sock = None
        self.server = server
        self.port = port
        self.ssl = ssl
        self.ssl_params = ssl_params
        self.pid = 0
        self.cb = None
        self.user = user
        self.pswd = password
        self.keepalive = keepalive
        self.lw_topic = None
        self.lw_msg = None
        self.lw_qos = 0
        self.lw_retain = False
        self.last_connect_status = None

    def _send_str(self, s):
        self.sock.write(struct.pack("!H", len(s)))
        self.sock.write(s)

    def _recv_len(self):
        n = 0
        sh = 0
        while 1:
            b = self.sock.read(1)[0]
            n |= (b & 0x7f) << sh
            if not b & 0x80:
                return n
            sh += 7

    def set_callback(self, f):
        self.cb = f

    def set_last_will(self, topic, msg, retain=False, qos=0):
        assert 0 <= qos <= 2
        assert topic
        self.lw_topic = topic
        self.lw_msg = msg
        self.lw_qos = qos
        self.lw_retain = retain

    def connect(self, clean_session=True):
        self.sock = socket.socket()
        addr = socket.getaddrinfo(self.server, self.port)[0][-1]
        self.sock.connect(addr)
        if self.ssl:
            import ussl
            self.sock = ussl.wrap_socket(self.sock, **self.ssl_params)
        premsg = bytearray(b"\x10\0\0\0\0\0")
        msg = bytearray(b"\x04MQTT\x04\x02\0\0")

        sz = 10 + 2 + len(self.client_id)
        msg[6] = clean_session << 1
        if self.user is not None:
            sz += 2 + len(self.user) + 2 + len(self.pswd)
            msg[6] |= 0xC0
        if self.keepalive:
            assert self.keepalive < 65536
            msg[7] |= self.keepalive >> 8
            msg[8] |= self.keepalive & 0x00FF
        if self.lw_topic:
            sz += 2 + len(self.lw_topic) + 2 + len(self.lw_msg)
            msg[6] |= 0x4 | (self.lw_qos & 0x1) << 3 | (self.lw_qos & 0x2) << 3
            msg[6] |= self.lw_retain << 5

        i = 1
        while sz > 0x7f:
            premsg[i] = (sz & 0x7f) | 0x80
            sz >>= 7
            i += 1
        premsg[i] = sz

        self.sock.write(premsg, i + 2)
        self.sock.write(msg)
        #print(hex(len(msg)), hexlify(msg, ":"))
        self._send_str(self.client_id)
        if self.lw_topic:
            self._send_str(self.lw_topic)
            self._send_str(self.lw_msg)
        if self.user is not None:
            self._send_str(self.user)
            self._send_str(self.pswd)
        resp = self.sock.read(4)
        assert resp[0] == 0x20 and resp[1] == 0x02
        self.last_connect_status = resp[3]
        if resp[3] != 0:
            raise MQTTException(str(resp[3]) + ' ' + self.get_last_connect_status_message())
        return resp[2] & 1

    def disconnect(self):
        self.sock.write(b"\xe0\0")
        self.sock.close()

    def ping(self):
        self.sock.write(b"\xc0\0")

    def publish(self, topic, msg, retain=False, qos=0):
        pkt = bytearray(b"\x30\0\0\0")
        pkt[0] |= qos << 1 | retain
        sz = 2 + len(topic) + len(msg)
        if qos > 0:
            sz += 2
        assert sz < 2097152
        i = 1
        while sz > 0x7f:
            pkt[i] = (sz & 0x7f) | 0x80
            sz >>= 7
            i += 1
        pkt[i] = sz
        #print(hex(len(pkt)), hexlify(pkt, ":"))
        self.sock.write(pkt, i + 1)
        self._send_str(topic)
        if qos > 0:
            self.pid += 1
            pid = self.pid
            struct.pack_into("!H", pkt, 0, pid)
            self.sock.write(pkt, 2)
        self.sock.write(msg)
        if qos == 1:
            while 1:
                op = self.wait_msg()
                if op == 0x40:
                    sz = self.sock.read(1)
                    assert sz == b"\x02"
                    rcv_pid = self.sock.read(2)
                    rcv_pid = rcv_pid[0] << 8 | rcv_pid[1]
                    if pid == rcv_pid:
                        return
        elif qos == 2:
            assert 0

    def subscribe(self, topic, qos=0):
        assert self.cb is not None, "Subscribe callback is not set"
        pkt = bytearray(b"\x82\0\0\0")
        self.pid += 1
        struct.pack_into("!BH", pkt, 1, 2 + 2 + len(topic) + 1, self.pid)
        #print(hex(len(pkt)), hexlify(pkt, ":"))
        self.sock.write(pkt)
        self._send_str(topic)
        self.sock.write(qos.to_bytes(1, "little"))
        while 1:
            op = self.wait_msg()
            if op == 0x90:
                resp = self.sock.read(4)
                #print(resp)
                assert resp[1] == pkt[2] and resp[2] == pkt[3]
                if resp[3] == 0x80:
                    raise MQTTException(resp[3])
                return

    # Wait for a single incoming MQTT message and process it.
    # Subscribed messages are delivered to a callback previously
    # set by .set_callback() method. Other (internal) MQTT
    # messages processed internally.
    def wait_msg(self):
        res = self.sock.read(1)
        self.sock.setblocking(True)
        if res is None:
            return None
        if res == b"":
            raise OSError(-1)
        if res == b"\xd0":  # PINGRESP
            sz = self.sock.read(1)[0]
            assert sz == 0
            return None
        op = res[0]
        if op & 0xf0 != 0x30:
            return op
        sz = self._recv_len()
        topic_len = self.sock.read(2)
        topic_len = (topic_len[0] << 8) | topic_len[1]
        topic = self.sock.read(topic_len)
        sz -= topic_len + 2
        if op & 6:
            pid = self.sock.read(2)
            pid = pid[0] << 8 | pid[1]
            sz -= 2
        msg = self.sock.read(sz)
        self.cb(topic, msg)
        if op & 6 == 2:
            pkt = bytearray(b"\x40\x02\0\0")
            struct.pack_into("!H", pkt, 2, pid)
            self.sock.write(pkt)
        elif op & 6 == 4:
            assert 0

    # Checks whether a pending message from server is available.
    # If not, returns immediately with None. Otherwise, does
    # the same processing as wait_msg.
    def check_msg(self):
        self.sock.setblocking(False)
        return self.wait_msg()

    def get_last_connect_status_message(self):
        if self.last_connect_status == None:
            return "(not defined)"
        elif self.last_connect_status in range(len(self.connect_status_codes)):
            return self.connect_status_codes[self.last_connect_status]
        else:
            return "UNKNOWN MQTT STATUS"

# ESP32 Wi-Fi class

class wifi():

    nic = None

    def reset(force=False, reply=5, is_hard=True):
        if force == False and __class__.isconnected():
            return True
        try:
            # IO map for ESP32 on Maixduino
            fm.register(25,fm.fpioa.GPIOHS10)#cs
            fm.register(8,fm.fpioa.GPIOHS11)#rst
            fm.register(9,fm.fpioa.GPIOHS12)#rdy

            if is_hard:
                print("Use Hardware SPI for Maixduino")
                fm.register(28,fm.fpioa.SPI1_D0, force=True)#mosi
                fm.register(26,fm.fpioa.SPI1_D1, force=True)#miso
                fm.register(27,fm.fpioa.SPI1_SCLK, force=True)#sclk
                __class__.nic = network.ESP32_SPI(cs=fm.fpioa.GPIOHS10, rst=fm.fpioa.GPIOHS11, rdy=fm.fpioa.GPIOHS12, spi=1)
                print("ESP32_SPI firmware version:", __class__.nic.version())
            else:
                # Running within 3 seconds of power-up can cause an SD load error
                print("Use Software SPI for other hardware")
                fm.register(28,fm.fpioa.GPIOHS13, force=True)#mosi
                fm.register(26,fm.fpioa.GPIOHS14, force=True)#miso
                fm.register(27,fm.fpioa.GPIOHS15, force=True)#sclk
                __class__.nic = network.ESP32_SPI(cs=fm.fpioa.GPIOHS10,rst=fm.fpioa.GPIOHS11,rdy=fm.fpioa.GPIOHS12, mosi=fm.fpioa.GPIOHS13,miso=fm.fpioa.GPIOHS14,sclk=fm.fpioa.GPIOHS15)
                print("ESP32_SPI firmware version:", __class__.nic.version())

            # time.sleep_ms(500) # wait at ready to connect
        except Exception as e:
            print(e)
            return False
        return True

    def connect(ssid="wifi_name", pasw="pass_word"):
        if __class__.nic != None:
            return __class__.nic.connect(ssid, pasw)

    def ifconfig(): # should check ip != 0.0.0.0
        if __class__.nic != None:
            return __class__.nic.ifconfig()

    def isconnected():
        if __class__.nic != None:
            return __class__.nic.isconnected()
        return False

def mqtt_connect(client):
    global mqtt_connected
    if not mqtt_connected:
        try:
            client.connect()
            mqtt_connected = True
            print("MQTT connected")
        except Exception as e:
            mqtt_connected = False
            print("MQTT connect failed: {}".format(e))
    else:
        print("MQTT already connected")

def mqtt_disconnect(client):
    global mqtt_connected
    if mqtt_connected:
        try:
            client.disconnect()
        except:
            pass
    mqtt_connected = False

def connect_wifi():
    while not wifi.isconnected():
        print("--- Reset ESP32 ---")
        wifi.reset()
        print("--- Connecting to Wi-Fi ---")
        try:
            wifi.connect(WIFI_SSID, WIFI_PASSWORD)
        except Exception as e:
            print("Connect failed: {}".format(e))

    print("Wi-Fi connected:", wifi.isconnected(), wifi.ifconfig())

    # Ping google.com

    ping_host = "google.com"

    print("--- Ping {}: {} ms ---".format(ping_host, wifi.nic.ping(ping_host)))

def connect_mqtt():
    global client, mqtt_connected
    client = MQTTClient(client_id=MQTT_CLIENT_ID, server=MQTT_BROKER, port=MQTT_PORT,
                        user=MQTT_USERNAME, password=MQTT_PASSWORD)
    while not mqtt_connected and wifi.isconnected():
        print("--- Connecting to MQTT broker {} ---".format(MQTT_BROKER))
        mqtt_connect(client)
        if not mqtt_connected:
            time.sleep(1)

def publish_mqtt():
    global client, mqtt_connected, face_count
    if not wifi.isconnected():
        if mqtt_connected:
            mqtt_disconnect(client)
            mqtt_connected = False
        connect_wifi()
    tries = 3
    while tries > 0:
        if not mqtt_connected:
            mqtt_connect(client)
        if mqtt_connected:
            msg = {'event_data': {'face_count':face_count, 'timestamp':time.ticks_ms()}}
            print("Publishing message: {}".format(json.dumps(msg)))
            try:
                client.publish(MQTT_PUB_TOPIC, json.dumps(msg))
                print("Message published")
                break
            except Exception as e:
                print("MQTT publish failed")
                ##sys.print_exception(e)
                mqtt_disconnect(client)
        else:
            print("MQTT not connected, publish failed")
        tries = tries - 1
        if tries > 0:
            print("Will retry {} more time(s)".format(tries))


def lcd_show_except(e):
    import uio
    err_str = uio.StringIO()
    sys.print_exception(e, err_str)
    err_str = err_str.getvalue()
    img = image.Image(size=(224,224))
    img.draw_string(0, 10, err_str, scale=1, color=(0xff,0x00,0x00))
    lcd.display(img)

def main(model_addr=0x300000, lcd_rotation=0, sensor_hmirror=False, sensor_vflip=False):
    global face_count, last_face_count
    sensor.reset()
    sensor.set_pixformat(sensor.RGB565)
    sensor.set_framesize(sensor.QVGA)
    sensor.set_hmirror(sensor_hmirror)
    sensor.set_vflip(sensor_vflip)
    sensor.run(1)

    lcd.init(type=1)
    lcd.rotation(lcd_rotation)
    lcd.clear(lcd.WHITE)

    task = kpu.load(model_addr)
    anchors = (1.889, 2.5245, 2.9465, 3.94056, 3.99987, 5.3658, 5.155437, 6.92275, 6.718375, 9.01025)
    kpu.init_yolo2(task, 0.5, 0.3, 5, anchors) # threshold:[0,1], nms_value: [0, 1]
    try:
        while(True):
            img = sensor.snapshot()
            t = time.ticks_ms()
            objects = kpu.run_yolo2(task, img)
            t = time.ticks_ms() - t
            face_count = 0
            if objects:
                for obj in objects:
                    img.draw_rectangle(obj.rect())
                    face_count += 1
            if face_count != last_face_count:
                if last_face_count != -1:
                    print("Face count change from {} to {} !".format(last_face_count, face_count))
                publish_mqtt()  # send new face count to Medium One
                if face_count == 0:
                    print("No faces found")
            last_face_count = face_count
            img.draw_string(5, 200, "t:%dms, f:%d" %(t, face_count), scale=2)  # print face count on LCD
            lcd.display(img)
    except Exception as e:
        raise e
    finally:
        kpu.deinit(task)

# Main program

if __name__ == "__main__":
    try:
        connect_wifi()
        connect_mqtt()
        main( model_addr=0x300000, lcd_rotation=0, sensor_hmirror=False, sensor_vflip=False)
        # main(model_addr="/sd/m.kmodel")
    except Exception as e:
        sys.print_exception(e)
        lcd_show_except(e)
    finally:
        gc.collect()
        print("--- Disconnecting Wi-Fi ---")
        wifi.nic.disconnect()
